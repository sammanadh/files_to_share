import { AccumulatedEvents } from '@railgun-community/engine';

export const EMPTY_EVENTS: AccumulatedEvents = {
  commitmentEvents: [],
  unshieldEvents: [],
  nullifierEvents: [],
};
