export * from './extract-first-note';
