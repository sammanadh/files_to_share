import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { RegistryCreateAccountRecipe } from '../registry-create-account-recipe';
import { BigNumber } from 'ethers';
import {
  RecipeERC20Info,
  RecipeInput,
  SwapQuoteData,
} from '../../../models/export-models';
import { NETWORK_CONFIG, NetworkName } from '@railgun-community/shared-models';
import { setRailgunFees } from '../../../init';
import { getTestRailgunWallet } from '../../../test/shared.test';
import {
  MOCK_SHIELD_FEE_BASIS_POINTS,
  MOCK_UNSHIELD_FEE_BASIS_POINTS,
} from '../../../test/mocks.test';
import { balanceForERC20Token } from '@railgun-community/quickstart';
import { ZeroXQuote } from '../../../api/zero-x';
import { executeRecipeStepsAndAssertUnshieldBalances } from '../../../test/common.test';
// import { ZeroXConfig } from '../../../models/zero-x-config';

chai.use(chaiAsPromised);
const { expect } = chai;

const networkName = NetworkName.PolygonMumbai;
const sellTokenAddress = NETWORK_CONFIG[networkName].baseToken.wrappedAddress;
const buyTokenAddress = '0xe76C6c83af64e4C60245D8C7dE953DF673a7A33D';

const sellToken: RecipeERC20Info = {
  tokenAddress: sellTokenAddress, // WETH
  decimals: 18,
  isBaseToken: false,
};

const buyToken: RecipeERC20Info = {
  tokenAddress: buyTokenAddress, // RAIL
  decimals: 18,
};

const DEFAULT_ACCOUNT_ADDRESS = '0xAA40eE3b4Ad243C614E94B6c3FBD8248891fE327';
const CHAIN_ID = NETWORK_CONFIG[networkName].chain.id;
const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';
const MAX_UINT256_HEX =
  '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
const SALT = '4355654756765756765';
const REGISTRY_CONTRACT_ADDRESS = '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4';

const createAccountData = {
  implementation: DEFAULT_ACCOUNT_ADDRESS,
  chainId: BigNumber.from(CHAIN_ID),
  tokenContract: ZERO_ADDRESS,
  tokenId: MAX_UINT256_HEX,
  salt: BigNumber.from(SALT),
  initData: [],
};

const slippagePercentage = 0.01;

describe('FORK-registry-create-account-receipe', function run() {
  this.timeout(120000);

  before(async function run() {
    if (!process.env.RUN_FORK_TESTS) {
      this.skip();
      return;
    }

    setRailgunFees(
      networkName,
      MOCK_SHIELD_FEE_BASIS_POINTS,
      MOCK_UNSHIELD_FEE_BASIS_POINTS,
    );

    // ZeroXConfig.PROXY_API_DOMAIN = undefined;
  });

  it('[FORK] Should run registry-create-account-receipe', async function run() {
    if (!process.env.RUN_FORK_TESTS) {
      this.skip();
      return;
    }

    const recipe = new RegistryCreateAccountRecipe(
      createAccountData,
      REGISTRY_CONTRACT_ADDRESS,
    );
    const recipeInput: RecipeInput = {
      networkName,
      erc20Amounts: [],
      nfts: [],
    };

    const railgunWallet = getTestRailgunWallet();
    const initialPrivateRAILBalance = await balanceForERC20Token(
      railgunWallet,
      networkName,
      buyToken.tokenAddress,
    );

    const recipeOutput = await recipe.getRecipeOutput(recipeInput);
    await executeRecipeStepsAndAssertUnshieldBalances(
      recipe.config.name,
      recipeInput,
      recipeOutput,
      2_800_000, // expectedGasWithin50K
    );

    // const quote = recipe.getLatestQuote() as SwapQuoteData;
    // expect(quote).to.not.be.undefined;
    // const expectedSpender =
    //   ZeroXQuote.zeroXExchangeProxyContractAddress(networkName);
    // expect(quote.spender).to.equal(
    //   expectedSpender,
    //   '0x Exchange contract does not match.',
    // );

    // // REQUIRED TESTS:

    // // 1. Add New Private Balance expectations.
    // // Expect new swapped token in private balance.

    // const privateRAILBalance = await balanceForERC20Token(
    //   railgunWallet,
    //   networkName,
    //   buyToken.tokenAddress,
    // );

    // const minimumBuyAmount = quote.minimumBuyAmount;
    // const minimumShieldFee = minimumBuyAmount
    //   .mul(MOCK_SHIELD_FEE_BASIS_POINTS)
    //   .div(10000);
    // const expectedPrivateRAILBalance = initialPrivateRAILBalance
    //   .add(minimumBuyAmount) // Minimum buy amount
    //   .sub(minimumShieldFee); // Shield fee
    // expect(privateRAILBalance.gte(expectedPrivateRAILBalance)).to.equal(
    //   true,
    //   'Private RAIL balance incorrect after swap',
    // );

    // // 2. Add External Balance expectations.
    // // N/A
  });
});
