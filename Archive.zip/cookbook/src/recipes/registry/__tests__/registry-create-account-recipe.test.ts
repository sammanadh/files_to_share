import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { RegistryCreateAccountRecipe } from '../registry-create-account-recipe';
import { BigNumber } from 'ethers';
import { RecipeInput } from '../../../models/export-models';
import { NETWORK_CONFIG, NetworkName } from '@railgun-community/shared-models';
import { setRailgunFees } from '../../../init';
import {
  MOCK_SHIELD_FEE_BASIS_POINTS,
  MOCK_UNSHIELD_FEE_BASIS_POINTS,
} from '../../../test/mocks.test';

chai.use(chaiAsPromised);
const { expect } = chai;

const networkName = NetworkName.PolygonMumbai;

const DEFAULT_ACCOUNT_ADDRESS = '0xAA40eE3b4Ad243C614E94B6c3FBD8248891fE327';
const CHAIN_ID = NETWORK_CONFIG[networkName].chain.id;
const ZERO_ADDRESS = '0x0000000000000000000000000000000000000000';
const MAX_UINT256_HEX =
  '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
const SALT = '4355654756765756765';
const REGISTRY_CONTRACT_ADDRESS = '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4';

const createAccountData = {
  implementation: DEFAULT_ACCOUNT_ADDRESS,
  chainId: BigNumber.from(CHAIN_ID),
  tokenContract: ZERO_ADDRESS,
  tokenId: MAX_UINT256_HEX,
  salt: BigNumber.from(SALT),
  initData: [],
};

describe('registry-create-account-receipe', () => {
  before(() => {
    setRailgunFees(
      networkName,
      MOCK_SHIELD_FEE_BASIS_POINTS,
      MOCK_UNSHIELD_FEE_BASIS_POINTS,
    );
  });

  it('Should create a new account', async () => {
    const recipe = new RegistryCreateAccountRecipe(
      createAccountData,
      REGISTRY_CONTRACT_ADDRESS,
    );
    const recipeInput: RecipeInput = {
      networkName: networkName,
      erc20Amounts: [],
      nfts: [],
    };
    const output = await recipe.getRecipeOutput(recipeInput);

    expect(output.stepOutputs.length).to.equal(3);

    expect(output.stepOutputs[0]).to.deep.equal({
      name: 'Unshield',
      description: 'Unshield ERC20s and NFTs from private RAILGUN balance.',
      feeERC20AmountRecipients: [],
      outputERC20Amounts: [],
      outputNFTs: [],
      populatedTransactions: [],
      spentERC20Amounts: [],
      spentNFTs: [],
    });

    expect(output.stepOutputs[1]).to.deep.equal({
      name: 'Create Account',
      description: 'Deploys new account for the given data',
      feeERC20AmountRecipients: [],
      outputERC20Amounts: [],
      outputNFTs: [
        {
          amountString: '1',
          nftAddress: '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4',
          nftTokenType: 1,
          tokenSubID:
            '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',
        },
      ],
      populatedTransactions: [
        {
          data: '0xda7323b3000000000000000000000000aa40ee3b4ad243c614e94b6c3fbd8248891fe32700000000000000000000000000000000000000000000000000000000000138810000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000003c7264ec8d436d5d00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000000',
          to: '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4',
        },
      ],
      spentERC20Amounts: [],
      spentNFTs: [],
    });

    expect(output.stepOutputs[2]).to.deep.equal({
      description: 'Shield ERC20s and NFTs into private RAILGUN balance.',
      feeERC20AmountRecipients: [],
      name: 'Shield',
      outputERC20Amounts: [],
      outputNFTs: [
        {
          amountString: '1',
          nftAddress: '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4',
          nftTokenType: 1,
          tokenSubID:
            '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',
        },
      ],
      populatedTransactions: [],
      spentERC20Amounts: [],
      spentNFTs: [],
    });

    expect(output.erc20Amounts).to.deep.equal([]);

    expect(output.nfts).to.deep.equal([
      {
        amountString: '1',
        nftAddress: '0x62aBD72DB8327257cbfaB8bd4eC7b95Edeffc4f4',
        nftTokenType: 1,
        tokenSubID:
          '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',
      },
    ]);

    const populatedTransactionsFlattened = output.stepOutputs.flatMap(
      stepOutput => stepOutput.populatedTransactions,
    );
    expect(output.populatedTransactions).to.deep.equal(
      populatedTransactionsFlattened,
    );

    expect(output.feeERC20AmountRecipients).to.deep.equal([]);
  });
});
