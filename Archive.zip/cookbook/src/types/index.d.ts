declare type Optional<T> = T | undefined;

declare module 'snarkjs';
