export class ZeroXConfig {
  static PROXY_API_DOMAIN: Optional<string>;
}
