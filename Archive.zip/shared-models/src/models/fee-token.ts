export type FeeTokenDetails = {
  tokenAddress: string;
  feePerUnitGas: string;
};
