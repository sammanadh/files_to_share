export enum ProofType {
  Transfer = 'Transfer',
  Unshield = 'Unshield',
  UnshieldBaseToken = 'UnshieldBaseToken',
  CrossContractCalls = 'CrossContractCalls',
}
