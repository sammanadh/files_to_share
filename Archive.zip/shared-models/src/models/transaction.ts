export type TransactionReceiptLog = {
  topics: string[];
  data: string;
};
