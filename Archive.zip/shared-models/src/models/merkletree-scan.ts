export enum MerkletreeScanStatus {
  Started = 'Started',
  Updated = 'Updated',
  Complete = 'Complete',
  Incomplete = 'Incomplete',
}
