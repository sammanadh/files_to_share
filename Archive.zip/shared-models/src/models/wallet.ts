export enum WalletCreationType {
  Import = 'Import',
  Create = 'Create',
  AddViewOnly = 'AddViewOnly',
  ImportFromBackup = 'ImportFromBackup',
}
