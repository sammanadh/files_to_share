# Shared TypeScript models, types and various utils for RAILGUN SDKs

Compatible with browser, node and React environments.

`yarn add @railgun-community/shared-models`
