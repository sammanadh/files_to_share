enum ETokenType {
    NORMAL = 'normal',
    A_TOKEN = "atoken",
    DTOKEN = "dtoken"
}

export default ETokenType;