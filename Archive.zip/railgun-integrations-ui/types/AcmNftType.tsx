type AcmNftType = {
    id: number,
    contractAddress: string
}

export default AcmNftType;