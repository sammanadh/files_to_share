type AcmAccount = {
    id: string;
    contract: string
};

export default AcmAccount