type TokenFilterType = {
    aaveSupported?: boolean
}

export default TokenFilterType;