enum EInterestMode {
    STABLE = 1,
    VARIABLE = 2
}

export default EInterestMode;