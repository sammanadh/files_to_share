export const parseIPFSUri = (ipfsUri: string) => {
  return ipfsUri.slice(7);
};
