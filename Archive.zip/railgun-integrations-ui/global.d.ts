declare type Optional<T> = T | undefined
