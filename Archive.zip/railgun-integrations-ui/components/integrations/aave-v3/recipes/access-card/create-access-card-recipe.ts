import {
  Recipe,
  RecipeConfig,
  RecipeInput,
  RecipeOutput,
  StepInput,
  Step
} from '@railgun-community/cookbook';
import { NetworkName } from '@railgun-community/shared-models';
import { AccessCardNFT } from '../../api/access-card/access-card-nft';
import { AccessCardCreateNFTOwnerStep } from '../../steps/access-card/create-nft-owner-step';
import { AccessCardNFTMintStep } from '../../steps/access-card/nft-mint-step';
import { AccessCardSetNFTMetadataStep } from '../../steps/access-card/set-nft-metadata';

export const MIN_GAS_LIMIT_ANY_RECIPE: bigint = 2_800_000n;

export type RecipeCreateAccessCard = {
  encryptedNFTMetadata: string;
};

export class CreateAccessCardRecipe extends Recipe {
  readonly config: RecipeConfig = {
    name: 'Create Access Card',
    description: 'Creates an Ownable Contract and assigns Access Card NFT as owner',
    // minGasLimit: MIN_GAS_LIMIT_ANY_RECIPE,
  };

  private readonly createAccessCardData: RecipeCreateAccessCard;

  /**
   * Recipe to creates an ownable contract and assign Access Card NFT as owner
   * @param {string} encryptedNFTMetadata Access Card `name` and `description` encrypted with user's viewing key
   */
  constructor(encryptedNFTMetadata: string) {
    super();
    this.createAccessCardData = { encryptedNFTMetadata };
  }

  protected supportsNetwork(networkName: NetworkName): boolean {
    return AccessCardNFT.supportsNetwork(networkName);
  }

  protected async getInternalSteps(firstInternalStepInput: StepInput): Promise<Step[]> {
    const { networkName } = firstInternalStepInput;

    // Error thrown here if network is not supported
    const { erc721: accessCardNFTAddress } = AccessCardNFT.getAddressesForNetwork(networkName);

    return [
      new AccessCardNFTMintStep(accessCardNFTAddress),
      new AccessCardSetNFTMetadataStep(
        accessCardNFTAddress,
        this.createAccessCardData.encryptedNFTMetadata,
      ),
      new AccessCardCreateNFTOwnerStep(),
    ];
  }
}
