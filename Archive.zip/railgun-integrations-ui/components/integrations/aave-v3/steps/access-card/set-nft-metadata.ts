// import { AccessCardERC721Contract } from '../../contract/access-card/access-card-erc721-contract';
// import {
//   StepConfig,
//   StepInput,
//   UnvalidatedStepOutput,
// } from '../../models';
// import { Step } from '../../steps/step';

import {
  Step, // RecipeNFTInfo,
  StepConfig,
  StepInput,
  UnvalidatedStepOutput,
} from '@railgun-community/cookbook';
// import { Step } from '../../steps/step';
import { AccessCardERC721Contract } from '../../../../../contract/access-card/access-card-erc721-contract';


export class AccessCardSetNFTMetadataStep extends Step {
  readonly config: StepConfig = {
    name: 'Access Card Set NFT Metadata',
    description: 'Set Name and Description for the Access Card NFT as owner',
  };

  private readonly accessCardNFTAddress: string;

  private readonly encryptedNFTMetadata: string;

  constructor(
    accessCardNFTAddress: string,
    encryptedNFTMetadata: string,
  ) {
    super();
    this.accessCardNFTAddress = accessCardNFTAddress;
    this.encryptedNFTMetadata = encryptedNFTMetadata;
  }

  protected async getStepOutput(
    input: StepInput,
  ): Promise<UnvalidatedStepOutput> {
    const contract = new AccessCardERC721Contract(this.accessCardNFTAddress);

    const nftTokenSubID = 0n;

    let formattedEncryptedData = this.encryptedNFTMetadata;
    if(this.encryptedNFTMetadata.length < 64) {
      formattedEncryptedData = Array(64 - this.encryptedNFTMetadata.length).fill(0).join("") + this.encryptedNFTMetadata
    }

    const crossContractCall = await contract.setEncryptedMetadata(nftTokenSubID, formattedEncryptedData);

    return {
      populatedTransactions: [crossContractCall],
      outputERC20Amounts: input.erc20Amounts,
      outputNFTs: input.nfts,
      spentERC20Amounts: [],
      spentNFTs: [],
      feeERC20AmountRecipients: [],
    }
  }
}
