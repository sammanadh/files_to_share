import { RelayAdaptContract } from '../../../../../contract/adapt';
// import { StepConfig, StepInput, UnvalidatedStepOutput } from '../../models';
// import { Step } from '../../steps/step';
import {
  Step, // RecipeNFTInfo,
  StepConfig,
  StepInput,
  UnvalidatedStepOutput,
} from '@railgun-community/cookbook';

// import { Step } from '../../steps/step';

export class AccessCardCreateNFTOwnerStep extends Step {
  readonly config: StepConfig = {
    name: 'Access Card Create NFT Owner',
    description: 'Creates an Ownable Contract for a user',
  };

  constructor() {
    super();
  }

  protected async getStepOutput(input: StepInput): Promise<UnvalidatedStepOutput> {
    const { networkName } = input;

    const contract = new RelayAdaptContract(networkName);
    const crossContractCall = await contract.createNFTAccount();

    return {
      populatedTransactions: [crossContractCall],
      outputERC20Amounts: input.erc20Amounts,
      outputNFTs: input.nfts,
      spentERC20Amounts: [],
      spentNFTs: [],
      feeERC20AmountRecipients: [],
    };
  }
}
