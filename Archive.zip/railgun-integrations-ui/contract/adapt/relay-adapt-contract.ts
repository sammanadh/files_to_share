import {
  NETWORK_CONFIG,
  NetworkName, // isDefined,
} from '@railgun-community/shared-models';
import { Contract, ContractTransaction, PopulatedTransaction } from 'ethers';
import abi from '@/abi/adapt/RelayAdapt.json';
import { RelayAdapt } from '@/typechain';
// import { TokenDataStruct } from '@/typechain/adapt/RelayAdapt';
// import { validateContractAddress } from '@/utils/address';
import { ZERO_ADDRESS } from '@railgun-community/engine';

const isDefined = (network: any) => {
  return !!network;
};

export class RelayAdaptContract {
  private readonly contract: RelayAdapt;

  constructor(networkName: NetworkName) {
    const network = NETWORK_CONFIG[networkName];
    if (!isDefined(network)) {
      throw new Error(`Network not found: ${networkName}`);
    }
    // if (!validateContractAddress(network.relayAdaptContract)) {
    //   throw new Error('Invalid address for Relay Adapt contract.');
    // }
    this.contract = new Contract(
      '0x3aB4dA0f8fa0E0Bb3db60ceE269c90Ea296b9a5b',
      abi
    ) as unknown as any;
  }

  private createERC20TokenData(tokenAddress: string): any {
    return {
      tokenAddress,
      tokenType: 0, // ERC20
      tokenSubID: ZERO_ADDRESS,
    };
  }

  createBaseTokenWrap(amount?: bigint): Promise<PopulatedTransaction> {
    return this.contract.populateTransaction.wrapBase(
      // 0 will automatically wrap full balance.
      amount ?? 0n
    );
  }

  createBaseTokenUnwrap(amount?: bigint): Promise<PopulatedTransaction> {
    return this.contract.populateTransaction.unwrapBase(
      // 0 will automatically unwrap full balance.
      amount ?? 0n
    );
  }

  createBaseTokenTransfer(toAddress: string, amount?: bigint): Promise<PopulatedTransaction> {
    const baseTokenTransfer: any = {
      token: this.createERC20TokenData(ZERO_ADDRESS),
      to: toAddress,
      // 0 will automatically transfer full balance.
      value: amount ?? 0n,
    };
    return this.contract.populateTransaction.transfer([baseTokenTransfer]);
  }

  createERC20Transfer(toAddress: string, tokenAddress: string, amount?: bigint) {
    const erc20Transfer: any = {
      token: this.createERC20TokenData(tokenAddress),
      to: toAddress,
      // 0 will automatically transfer full balance.
      value: amount ?? 0n,
    };
    return this.contract.populateTransaction.transfer([erc20Transfer]);
  }

  createNFTAccount() {
    return this.contract.populateTransaction.createNftAccounts();
  }
}
