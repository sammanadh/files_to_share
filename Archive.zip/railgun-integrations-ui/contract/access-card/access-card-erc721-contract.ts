import { Contract, PopulatedTransaction } from 'ethers';
import abi from '@/abi/access-card/AccessCardERC721.json';
import { AccessCardERC721 } from '../../typechain';

export class AccessCardERC721Contract {
  private readonly contract: AccessCardERC721;

  constructor(tokenAddress: string) {
    this.contract = new Contract(
      tokenAddress,
      abi,
    ) as unknown as any;
  }

  mint(): Promise<PopulatedTransaction> {
    return this.contract.populateTransaction.mint();
  }

  setEncryptedMetadata(tokenId: bigint, encryptedMetadata: string): Promise<PopulatedTransaction> {
    return this.contract.populateTransaction.setEncryptedMetadata(tokenId, `0x` + encryptedMetadata);
  }
}
