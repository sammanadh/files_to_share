import { Contract, ContractTransaction, Provider } from 'ethers';
import abi from '@/abi/access-card/AccessCardAccountCreator.json';
// import { AccessCardAccountCreator } from '../../typechain';
// import { validateContractAddress } from '../../utils/address';

export class AccessCardAccountCreatorContract {
  private readonly contract: any;

  constructor(address: string, provider: Provider) {
    // if (!validateContractAddress(address)) {
    //   throw new Error(
    //     'Invalid factory address for Access Card Account Creator contract',
    //   );
    // }
    this.contract = new Contract(
      address,
      abi,
      provider,
    ) as unknown as any;
  }

  getAddress(nftAddress: string, nftTokenSubID: bigint): Promise<string> {
    return this.contract.getAddress(nftAddress, nftTokenSubID);
  }

  createDeploy(
    nftAddress: string,
    nftTokenSubID: bigint,
  ): Promise<ContractTransaction> {
    return this.contract.deploy.populateTransaction(nftAddress, nftTokenSubID);
  }
}
