import abi from '@/abi/access-card/AccessCardOwnerAccount.json';
// import { validateContractAddress } from '../../utils/address';
// import { AccessCardOwnerAccount } from '../../typechain';
import { Contract, ContractTransaction } from 'ethers';

export class AccessCardOwnerAccountContract {
  private readonly contract: any;

  constructor(address: string) {
    // if (!validateContractAddress(address)) {
    //   throw new Error(
    //     'Invalid factory address for Access Card Account Owner contract',
    //   );
    // }
    this.contract = new Contract(
      address,
      abi,
    ) as unknown as any;
  }

  createCall(
    to: string,
    data: string,
    value: bigint,
  ): Promise<ContractTransaction> {
    return this.contract.call.populateTransaction(to, data, value);
  }
}
