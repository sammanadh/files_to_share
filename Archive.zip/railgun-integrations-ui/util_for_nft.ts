import { ByteLength, BytesData, CTRCiphertext, formatToByteLength, padToLength, randomHex, trim } from '@railgun-community/engine';
import BN from 'bn.js';
import { createCipheriv, createDecipheriv } from 'crypto';

const isPrefixed = (str: string): boolean => str.startsWith('0x');

const strip0x = (str: string): string => (isPrefixed(str) ? str.slice(2) : str);

export function arrayify(data: BytesData): number[] {
  // If we're a BN object, convert to bytes array and return
  if (data instanceof BN) {
    // Else return bytes array
    return data.toArray();
  }

  // If we're already a byte array return array coerced data
  if (typeof data !== 'string') {
    return Array.from(data);
  }

  // Remove leading 0x if exists
  const dataFormatted = strip0x(data);

  // Create empty array
  const bytesArray: number[] = [];

  // Loop through each byte and push to array
  for (let i = 0; i < dataFormatted.length; i += 2) {
    const number = parseInt(dataFormatted.substr(i, 2), 16);
    if (Number.isNaN(number)) {
      throw new Error('Invalid BytesData');
    } else {
      bytesArray.push(number);
    }
  }

  // Return bytes array
  return bytesArray;
}

export function hexlify(data: BytesData, prefix = false): string {
  let hexString = '';

  if (typeof data === 'string') {
    // If we're already a string return the string
    // Strip leading 0x if it exists before returning
    hexString = strip0x(data);
  } else if (data instanceof BN) {
    // If we're a BN object convert to string
    // Return hex string 0 padded to even length, if length is 0 then set to 2
    hexString = data.toString('hex', data.byteLength() * 2 || 2);
  } else {
    // We're an ArrayLike
    // Coerce ArrayLike to Array
    const dataArray: number[] = Array.from(data);

    // Convert array of bytes to hex string
    hexString = dataArray.map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  // Return 0x prefixed hex string if specified
  if (prefix) {
    return `0x${hexString}`.toLowerCase();
  }

  // Else return plain hex string
  return hexString.toLowerCase();
}

export const aes = {
  ctr: {
    /**
     * Encrypt blocks of data with AES-256-CTR
     * @param plaintext - plaintext to encrypt
     * @param key - key to encrypt with
     * @returns ciphertext bundle
     */
    encrypt(plaintext: string[], key: BytesData): CTRCiphertext {
      // If types are strings, convert to bytes array
      const plaintextFormatted = plaintext.map((block) => new Uint8Array(arrayify(block)));
      const keyFormatted = new Uint8Array(arrayify(key));
      if (keyFormatted.byteLength !== 32) {
        throw new Error(
          `Invalid key length. Expected 32 bytes. Received ${keyFormatted.byteLength} bytes.`
        );
      }

      const iv = randomHex(16);
      const ivFormatted = new Uint8Array(arrayify(iv));

      // Initialize cipher
      const cipher = createCipheriv('aes-256-ctr', keyFormatted, ivFormatted);

      // Loop through data blocks and encrypt
      const data = plaintextFormatted
        .map((block) => cipher.update(block))
        .map((block) => block.toString('hex'));
      cipher.final();

      // Return encrypted data bundle
      return {
        iv: formatToByteLength(ivFormatted, ByteLength.UINT_128, false),
        data,
      };
    },

    /**
     * Decrypts AES-256-CTR encrypted data
     * On failure, it throws `Unsupported state or unable to authenticate data`
     * @param ciphertext - ciphertext bundle to decrypt
     * @param key - key to decrypt with
     * @returns - plaintext
     */
    decrypt(ciphertext: CTRCiphertext, key: BytesData): string[] {
      // If types are strings, convert to bytes array
      const ciphertextFormatted = ciphertext.data.map((block) => new Uint8Array(arrayify(block)));
      const keyFormatted = new Uint8Array(arrayify(padToLength(key, 32)));
      const ivFormatted = new Uint8Array(arrayify(trim(ciphertext.iv, 16)));

      // Initialize decipher
      const decipher = createDecipheriv('aes-256-ctr', keyFormatted, ivFormatted);

      // Loop through ciphertext and decrypt then return
      const data = ciphertextFormatted
        .map((block) => decipher.update(block))
        .map((block) => block.toString('hex'));
      decipher.final();
      return data;
    },
  },
};
